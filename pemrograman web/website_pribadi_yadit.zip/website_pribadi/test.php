<?php
echo "PHP Berhasil Berjalan!";
?>